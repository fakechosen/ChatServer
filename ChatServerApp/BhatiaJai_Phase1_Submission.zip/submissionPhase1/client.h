#pragma once
#include "platform.h"
#include "definitions.h"


class client
{
	


};
